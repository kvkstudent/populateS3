import json
import pymysql

def lambda_handler(event, context):
    # Extracting host parameter from the event
    host = event['host']

    # MySQL database connection parameters
    db_config = {
        'host': host,
        'user': 'bnoel',
        'password': 'cgXh3vzM5aLFPb5',
    }
    
    # Connect to MySQL server
    try:
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()

        # Create database if not exists
        cursor.execute("CREATE DATABASE IF NOT EXISTS uni_schema")
        cursor.execute("USE uni_schema")

        # Create table if not exists
        cursor.execute("CREATE TABLE IF NOT EXISTS uni_table (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), dob DATE, ssn VARCHAR(255), bank_routing_number VARCHAR(255), personal_email VARCHAR(255), home_address VARCHAR(255))")

        # Insert data into the table
        sql = "INSERT INTO uni_table (name, dob, ssn, bank_routing_number, personal_email, home_address) VALUES (%s, %s, %s, %s, %s, %s)"
        val = [
            ('John', '1990-05-15', '123-45-6789', '123456789', 'john@example.com', '123 Main St'),
            ('Alice', '1995-08-20', '987-65-4321', '987654321', 'alice@example.com', '456 Elm St'),
            ('Bob', '1985-03-10', '456-78-9012', '456789012', 'bob@example.com', '789 Oak St')
        ]
        cursor.executemany(sql, val)
    
        # Commit changes
        conn.commit()
        print("Table created and data inserted successfully!")
    
        # Query Bob's DOB
        cursor.execute("SELECT dob FROM uni_table WHERE name = 'Bob'")
        bob_dob = cursor.fetchone()[0]  # Fetch the first row and first column value
        
        print("Bob's date of birth:", bob_dob)
    
    except pymysql.Error as error:
        print("Error:", error)
    
    finally:
        # Close connection
        if 'conn' in locals() and conn.open:
            cursor.close()
            conn.close()
    
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps({'Bob_dob': str(bob_dob)})
    }
